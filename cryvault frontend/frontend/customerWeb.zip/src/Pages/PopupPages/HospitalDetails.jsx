import React from 'react'

const HospitalDetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default HospitalDetails
