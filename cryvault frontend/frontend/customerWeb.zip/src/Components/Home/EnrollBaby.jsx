import { Box, Button, Container, Typography } from "@mui/material";
import React from "react";
import useDeviceSize from "../../Utilities/useDeviceSize";
import { Link } from "react-router-dom";
const EnrollBaby = () => {
  const isMobile = useDeviceSize() === "xs";

  return (
    <Container sx={{ marginTop: "15rem", display: "flex", flexDirection: isMobile ? " column" : "row ", gap: "1rem" }}>
      <Box className="enrollText" style={{ alignItems: isMobile ? 'center' : "start", width: isMobile ? "100%" : "50%" }}>
        <Typography sx={{ textAlign: isMobile ? "center" : "start", fontSize: isMobile ? "2.5rem" : '67px', fontWeight: "600" }} variant="h1">
          Be Prepared for the Unknown.
        </Typography>
        <Typography sx={{ textAlign: isMobile ? "center" : "start", fontSize: "1.5rem", fontWeight: isMobile ? "400" : "00" }} variant="h4">
          You only have one chance to preserve your baby’s life-saving stem cells, and that’s the day they are born. Secure your family’s healthy future by enrolling in stem cell banking today.
        </Typography>
        {/* <Button variant="contained" sx={{ textTransform:"none", backgroundColor: "#D5008D", color: "white", fontSize: "1rem", fontWeight: "700", width: isMobile ? "40%" :"25%",whiteSpace:"nowrap", padding: "15px 30px" }} size="lg">
          Enroll Now
        </Button> */}
        <Box className="about-btn sal-animate" data-sal-delay="400" data-sal="slide-up" data-sal-duration="1000">
          <Link href="#" className="edu-btn">
            Enroll Now
          </Link>
        </Box>
      </Box>
      <Box className="enrollImage">
        <img className="main-img-1 sal-animate" src="assets/images/img-1-2.webp" width="550" />
      </Box>
    </Container>
  );
};

export default EnrollBaby;
